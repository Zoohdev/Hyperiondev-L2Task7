public class projectDetails {

   
    int projectNum;
    String projectName;
    String buildingType;
    String buildingLocation;
    int ERF;
    int totalCost;
    int totalCurrentAmountPaid;
    String deadline;


    public projectDetails(int projectNum, String projectName, String buildingType, String buildingLocation, int ERF, int totalCost, int totalCurrentAmountPaid, String deadline)
    {
        this.projectNum = projectNumber;
        this.projectName = projectName;
        this.buildingType = buildingType;
        this.buildingLocation = buildingLocation;
        this.ERF = ERF;
        this.totalCost = totalCost;
        this.totalCurrentAmountPaid = totalCurrentAmountPaid;
        this.deadline = deadline;
    }

  
    public String toString()
    {
        String output = "Project Number:" + projectNum;
        output += "\nProject Name:" + projectName;
        output += "\nBuilding Type:" + buildingType;
        output += "\nBuilding Location:" + buildingLocation;
        output += "\nERF number:" + ERF;
        output += "\nTotal project cost:" + totalCost;
        output += "\nThe total amount currently paid:" + totalCurrentAmountPaid;
        output += "\nProject deadline:" + deadline;

        return output;
    }

}