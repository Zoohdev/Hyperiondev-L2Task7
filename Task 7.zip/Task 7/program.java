import java.util.Scanner;

public class poisedProject {

    public static void main(String[] args)
    {
    // Variables for project information
        String customerName;
        String customerSurname;
        int customerMobile;
        String customerEmail;
        String customerAddress;

        String architectName;
        String architectSurname;
        int architectMobile;
        String architectEmail;
        String architectAddress;

        String contractorName;
        String contractorSurname;
        int contractorMobile;
        String contractorEmail;
        String contractorAddress;


        Scanner input = new Scanner(System.in);

        // clears scanner so that we don't skip lines
        System.out.println("Enter  customer's first name");
        input = new Scanner(System.in); 
        customerName = input.nextLine();

        System.out.println("Enter customer's surname");
        input = new Scanner(System.in); 
        customerSurname = input.nextLine();

        System.out.println("Enter  customer's mobile number");
        input = new Scanner(System.in); 
        customerMobile = input.nextInt();

        System.out.println("Enter customer's email");
        input = new Scanner(System.in); 
        customerEmail = input.nextLine();

        System.out.println("Enter customer's address");
        input = new Scanner(System.in); 
        customerAddress = input.nextLine();
        System.out.println("\n");

 
        staffDetails customer = new staffDetails(customerName, customerSurname, customerMobile, customerEmail, customerAddress);


        System.out.println("Customer details:");
        System.out.println(customer.toString());
        System.out.println("\n");

//----------------- Requests architects information 
        System.out.println("Enter Architect's first name");
        input = new Scanner(System.in); 
        architectName = input.nextLine();

        System.out.println("Enter Architect's surname");
        input = new Scanner(System.in); 
        architectSurname = input.nextLine();

        System.out.println("Enter the Architect's mobile number");
        input = new Scanner(System.in); 
        architectMobile = input.nextInt();

        System.out.println("Enter Architect's email");
        input = new Scanner(System.in); 
        architectEmail = input.nextLine();

        System.out.println("Enter Architect's address");
        input = new Scanner(System.in); 
        architectAddress = input.nextLine();
        System.out.println("\n");


        staffDetails architect = new staffDetails(architectName, architectSurname, architectMobile, architectEmail, architectAddress);

        System.out.println("Architect details:");
        System.out.println(architect.toString());
        System.out.println("\n");

// Requests Contractor information 
        System.out.println("Enter  Contractor's first name");
        input = new Scanner(System.in); 
        contractorName = input.nextLine();

        System.out.println("Enter  Contractor's second name");
        input = new Scanner(System.in); 
        contractorSurname = input.nextLine();

        System.out.println("Enter Contractor's mobile number");
        input = new Scanner(System.in); 
        contractorMobile = input.nextInt();

        System.out.println("Enter Contractor's email");
        input = new Scanner(System.in); 
        contractorEmail = input.nextLine();

        System.out.println("Enter Contractor's address");
        input = new Scanner(System.in); 
        contractorAddress = input.nextLine();
        System.out.println("\n");

        staffDetails contractor = new staffDetails(contractorName, contractorSurname, contractorMobile, contractorEmail, contractorAddress);

// Printed out Contractors details and the toString method for new object - Contractor - created.
        System.out.println("Contractor details:");
        System.out.println(contractor.toString());
        System.out.println("\n");



            // Create Project

 // Variables for information to be requested for project to be created
        int projectNum = 0;
        String buildingType = null;
        String projectName = null;
        String buildingLocation = null;
        int ERF = 0;
        int totalCost = 0;
        int totalCurrentAmountPaid = 0;
        String deadline = null;

        System.out.println("Enter project number");
        input = new Scanner(System.in); 
        projectNum = input.nextInt();

        System.out.println("Enter building type");
        input = new Scanner(System.in); 
        buildingType = input.nextLine();

        System.out.println("Enter project name (leave blank to auto generate name): ");
        input = new Scanner(System.in); 
        projectName = input.nextLine();

 // If statement runs if user selects to leave the project name blank for auto generation of a project name
        if (projectName.equals(""))
        {
            projectName = buildingType + " " + customerSurname; // project name autogenerated if project name left blank
        }

        System.out.println("Enter building location: ");
        input = new Scanner(System.in); 
        buildingLocation = input.nextLine();

        System.out.println("Enter ERF number: ");
        input = new Scanner(System.in); 
        ERF = input.nextInt();

        System.out.println("Enter total cost of project");
        input = new Scanner(System.in); 
        totalCost = input.nextInt();

        System.out.println("Enter total amount currently paid: ");
        input = new Scanner(System.in);
        totalCurrentAmountPaid = input.nextInt();

        System.out.println("Enter project deadline: ");
        input = new Scanner(System.in); 
        deadline = input.nextLine();
        System.out.println("\n");


 // Create new object called newProject from projectDetails class
        projectDetails newProject = new projectDetails(projectNum, projectName, buildingType, buildingLocation, ERF, totalCost, totalCurrentAmountPaid, deadline);

 // Print out new project
        System.out.println(newProject.toString());
        System.out.println("\n");



//Print menu using while loop
        while (true)
        {
            String menuSelection;
            input = new Scanner(System.in); 


            System.out.println("MENU:");
            System.out.println("1 - Change due date of project");
            System.out.println("2 - Change total amount of current fee paid");
            System.out.println("3 - Update the contractor's contact details");
            System.out.println("4 - Quit");

            menuSelection = input.nextLine();  

 // If user selects '1' from the menu, they will be able to update the project deadline.
            if (menuSelection.equals("1"))
            {
                System.out.println("Enter new project deadline: ");
                input = new Scanner(System.in); 
                deadline = input.nextLine();
                System.out.println("\n");

 // New object called - projectUpdated - created - in projectDetails class
                projectDetails projectUpdated = new projectDetails(projectNum, projectName, buildingType, buildingLocation, ERF, totalCost, totalCurrentAmountPaid, deadline);

 
                System.out.println(projectUpdated.toString());
                System.out.println("\n");
            }

 // If user selects '2' from the menu, they will be able to update the total amount currently paid.
            if (menuSelection.equals("2"))
            {
                System.out.println("Enter total amount currently paid: ");
                input = new Scanner(System.in); 
                totalAmountPaidCurrently = input.nextInt();
                System.out.println("\n");

 // Created new object called projectUpdated from projectDetails class
                projectDetails projectUpdated = new projectDetails(projectNum, projectName, buildingType, buildingLocation, ERF, totalCost, totalCurrentAmountPaid, deadline);

                System.out.println(projectUpdated.toString());
                System.out.println("\n");

            }

 // If user selects '3' from the menu, they will be able to update the contractor's details.
            if (menuSelection.equals("3"))
            {
                System.out.println("Update the contractor's details: ");
                input = new Scanner(System.in); 

                System.out.println("Enter the contractor's first name");
                input = new Scanner(System.in); 
                contractorName = input.nextLine();

                System.out.println("Enter the contractor's surname");
                input = new Scanner(System.in); 
                contractorSurname = input.nextLine();

                System.out.println("Enter the contractor's mobile number");
                input = new Scanner(System.in); 
                contractorMobile = input.nextInt();

                System.out.println("Enter the contractor's email");
                input = new Scanner(System.in); 
                contractorEmail = input.nextLine();

                System.out.println("Enter the contractor's address");
                input = new Scanner(System.in); 
                contractorAddress = input.nextLine();
                System.out.println("\n");
// Create a new object called contractorUpdated.
                staffDetails contractorUpdated = new staffDetails(contractorName, contractorSurname, contractorMobile, contractorEmail, contractorAddress);

 // Print new object
                System.out.println("Updated contractor details:");
                System.out.println(contractorUpdated.toString());
                System.out.println("\n");

            }
 // If user selects '4' they will exit the program.
            if (menuSelection.equals("4"))
            {
                System.out.println("You have exited the program! ");
                break;
            }

            }
    }
}